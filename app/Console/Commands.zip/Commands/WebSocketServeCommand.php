<?php

namespace App\Console\Commands;  

use Illuminate\Console\Command;  
use Ratchet\App;  
use App\WebSockets\WebSocketServer;

class WebSocketServeCommand extends Command  
{  
    protected $signature = 'websocket:serve {host=localhost} {port=8080}';  
    protected $description = 'Démarre le serveur WebSocket';  

    public function handle()  
    {  
        $host = $this->argument('host');  
        $port = $this->argument('port');  

        $app = new App($host, $port);  
        $app->route('/ws', new WebSocketServer);  
        $app->run();  
    }  
}
