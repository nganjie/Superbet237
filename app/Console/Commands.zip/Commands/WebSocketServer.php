<?php

// app/Console/Commands/WebSocketServer.php
namespace App\Console\Commands;

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB; // Pour exécuter des requêtes SQL avec Laravel
use React\EventLoop\Loop;
use React\EventLoop\LoopInterface;

class WebSocketServer implements MessageComponentInterface
{

    protected $clients;
    protected LoopInterface $loop;
    private array $timers;

    public function __construct()
    {
        $this->clients = new \SplObjectStorage;
        $this->timers = []; // Initialisation de la propriété timers
        $this->loop = Loop::get();
    }

    /*  public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        echo "New connection! ({$conn->resourceId})\n";
    } */

    // Lorsque la connexion est établie
    public function onOpen(ConnectionInterface $conn)
    {
        // Ajouter le client à la liste des connexions
        $this->clients->attach($conn);
        echo "New connection! ({$conn->resourceId})\n";

    }

    public function onMessage(ConnectionInterface $from, $msg)
{
    $data = json_decode($msg, true);

    // Vérifiez le type de message
    if (isset($data['type']) && $data['type'] === 'join' && isset($data['code_salle'])) {
        $code_salle = $data['code_salle'];

        // Maintenant, vous pouvez utiliser $code_salle comme nécessaire
        echo "Client {$from->resourceId} joined with code salle: {$code_salle}\n";

        // Synchronisez l'état de la salle avec le code reçu
        $this->syncSalleState($from, $code_salle);
    }
}


    public function onClose(ConnectionInterface $conn)
    {
        // Enlevez le timer lorsque la connexion est fermée
        if (isset($this->timers[$conn->resourceId])) {
            $this->loop->cancelTimer($this->timers[$conn->resourceId]);
            unset($this->timers[$conn->resourceId]);
        }
        $this->clients->detach($conn);
        echo "Connection {$conn->resourceId} has disconnected\n";
    }


    public function onError(ConnectionInterface $conn, \Exception $e)
    {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }





    // Méthode pour exécuter la procédure stockée et envoyer les résultats
    private function syncSalleState(ConnectionInterface $conn, $code_salle)
    {
        try {
            // Exécuter la procédure stockée et obtenir les résultats
            $results = DB::select('CALL psSalleSync_Select(?)', [$code_salle]);

            // Envoyer les résultats au client connecté
            $conn->send(json_encode($results));
        } catch (\Exception $e) {
            // En cas d'erreur, envoyer le message d'erreur
            $conn->send(json_encode(['error' => $e->getMessage()]));
        }
    }
}
